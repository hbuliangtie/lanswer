function nSig=normsig(oSig)
% Normalize signal to rescale the signal intensity between 0 and 1
% [input]
%   oSig: original signal matrix, each row is a variable (channel).
% [output]
%   nSig: normlized signal matrix
%
% Author: Lu, Chia-Feng 2013.12.12

[rows,cols] = size(oSig);

nSig = (oSig-min(oSig,[],2)*ones(1,cols))./((max(oSig,[],2)-min(oSig,[],2))*ones(1,cols));